package com.example.cherkihamza

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
